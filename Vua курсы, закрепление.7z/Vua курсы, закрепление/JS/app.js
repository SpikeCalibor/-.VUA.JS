const { createApp, ref, computed } = Vue;

createApp({
  setup() {
    // Course title
    const courseTitle = ref('Vue.js 3 Fundamentals Course Project');
    
    // Template Syntax
    const message = ref('Hello Vue 3!');
    const rawHtml = ref('<span style="color: red">This is raw HTML</span>');
    
    // List Rendering
    const items = ref(['Item 1', 'Item 2', 'Item 3']);
    
    // User Inputs
    const inputText = ref('');
    
    // Events
    const counter = ref(0);
    
    // Conditional Rendering
    const showContent = ref(true);
    
    // Computed Properties
    const reversedMessage = computed(() => {
      return message.value.split('').reverse().join('');
    });
    
    return {
      courseTitle,
      message,
      rawHtml,
      items,
      inputText,
      counter,
      showContent,
      reversedMessage
    };
  }
}).mount('#app');