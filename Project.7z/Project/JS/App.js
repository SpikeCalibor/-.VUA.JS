const { createApp, ref, computed, onMounted } = Vue;

createApp({
  setup() {
    const darkMode = ref(false);
    const newTask = ref({
      text: '',
      time: ''
    });
    const tasks = ref([]);
    const filter = ref('all');

    const filteredTasks = computed(() => {
      switch (filter.value) {
        case 'active': return tasks.value.filter(t => !t.completed);
        case 'completed': return tasks.value.filter(t => t.completed);
        default: return tasks.value;
      }
    });

    const loadTasks = () => {
      const savedTasks = localStorage.getItem('vue-todo-tasks');
      const savedTheme = localStorage.getItem('vue-todo-theme');
      if (savedTasks) tasks.value = JSON.parse(savedTasks);
      if (savedTheme) darkMode.value = JSON.parse(savedTheme);
    };

    const saveTasks = () => {
      localStorage.setItem('vue-todo-tasks', JSON.stringify(tasks.value));
      localStorage.setItem('vue-todo-theme', JSON.stringify(darkMode.value));
    };

    const addTask = () => {
      if (newTask.value.text.trim()) {
        tasks.value.push({
          id: Date.now(),
          text: newTask.value.text.trim(),
          time: newTask.value.time,
          completed: false
        });
        newTask.value.text = '';
        newTask.value.time = '';
        saveTasks();
      }
    };

    const removeTask = (id) => {
      tasks.value = tasks.value.filter(task => task.id !== id);
      saveTasks();
    };

    const toggleTheme = () => {
      darkMode.value = !darkMode.value;
      saveTasks();
    };

    onMounted(() => {
      loadTasks();
    });

    return {
      darkMode,
      newTask,
      tasks,
      filter,
      filteredTasks,
      addTask,
      removeTask,
      toggleTheme,
      saveTasks
    };
  }
}).mount('#app');